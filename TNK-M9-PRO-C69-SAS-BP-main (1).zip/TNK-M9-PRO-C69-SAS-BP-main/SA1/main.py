# import required libraries



# Capture the camera feed and set the resolution


# Loop to display video

        # Get a single capture from the camera
        

    
    # Show the camera feed image
   
