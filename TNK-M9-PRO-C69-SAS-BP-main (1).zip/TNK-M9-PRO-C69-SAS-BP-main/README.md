# TNK-M9-PRO-C69-SAS-BP

Class 69 student activities boilerplate code

To run the project follow the below commands:

```
* git clone https://github.com/Tynker-Computer-Vision/TNK-M9-PRO-C69-TAS-BP.git
* cd TNK-M9-PRO-C69-TAS-BP
* python3 -m venv myenv
* source myenv/bin/activate
* pip install -r requirements.txt
* python3 main.py
```

---
